import os
import random
import statistics as stats
import standard_aes as std
import modified_aes as mod

TRIALS = 100
MSG_SIZE = 16          # single-block plaintext to mirror "block" avalanche
WORKLOAD = 10000       # PBKDF2 iterations

def hb(a: bytes, b: bytes) -> int:
    return sum((x ^ y).bit_count() for x, y in zip(a, b))

class DRBG:
    def __init__(self, seed: int):
        self.r = random.Random(seed)
    def urandom(self, n: int) -> bytes:
        return bytes(self.r.getrandbits(8) for _ in range(n))

def flip_bit(data: bytes, bit_index: int) -> bytes:
    ba = bytearray(data)
    i = bit_index // 8
    ba[i] ^= 1 << (bit_index % 8)
    return bytes(ba)

def enc_std_with_seed(K: bytes, msg: bytes, seed: int) -> bytes:
    drbg = DRBG(seed)
    orig = std.os.urandom
    std.os.urandom = drbg.urandom
    try:
        return std.encrypt(K, msg, WORKLOAD)
    finally:
        std.os.urandom = orig

def enc_mod_with_seed(K: bytes, msg: bytes, seed: int) -> bytes:
    drbg = DRBG(seed)
    orig = mod.os.urandom
    mod.os.urandom = drbg.urandom
    try:
        return mod.encrypt(K, msg, WORKLOAD, shift_mode='dynamic')
    finally:
        mod.os.urandom = orig

def main():
    std_scores, mod_scores = [], []

    for t in range(TRIALS):
        seed = 13579 + t  # per-trial deterministic salt/IV for fair compare
        K = os.urandom(16)
        P = os.urandom(MSG_SIZE)
        bit = random.randrange(MSG_SIZE * 8)
        P2 = flip_bit(P, bit)

        C1 = enc_std_with_seed(K, P, seed)
        C2 = enc_std_with_seed(K, P2, seed)
        std_scores.append(hb(C1, C2))

        MC1 = enc_mod_with_seed(K, P, seed)
        MC2 = enc_mod_with_seed(K, P2, seed)
        mod_scores.append(hb(MC1, MC2))

    ms = lambda xs: float(stats.mean(xs)) if xs else 0.0
    s_avg, m_avg = ms(std_scores), ms(mod_scores)

    print(f"Full-pipeline block avalanche on ciphertext (higher is better), {TRIALS} trials:")
    print(f"- Standard AES:  {s_avg:.3f} bits")
    print(f"- Modified AES:  {m_avg:.3f} bits")
    print(f"Winner: {'Modified' if m_avg > s_avg else 'Standard'}")

if __name__ == "__main__":
    main()