import os, random, statistics as stats, math
import standard_aes as std
import modified_aes as mod

TRIALS = 100
MSG_SIZE = 1024
WORKLOAD = 10000
SAMPLE_BITS = 256  # number of ciphertext bit positions to evaluate BIC on

class DRBG:
    def __init__(self, seed: int):
        self.r = random.Random(seed)
    def urandom(self, n: int) -> bytes:
        return bytes(self.r.getrandbits(8) for _ in range(n))

def flip_bit(data: bytes, bit_index: int) -> bytes:
    ba = bytearray(data)
    i = bit_index // 8
    ba[i] ^= 1 << (bit_index % 8)
    return bytes(ba)

def enc_std_with_seed(K: bytes, msg: bytes, seed: int) -> bytes:
    drbg = DRBG(seed)
    orig = std.os.urandom
    std.os.urandom = drbg.urandom
    try:
        return std.encrypt(K, msg, WORKLOAD)
    finally:
        std.os.urandom = orig

def enc_mod_with_seed(K: bytes, msg: bytes, seed: int) -> bytes:
    drbg = DRBG(seed)
    orig = mod.os.urandom
    mod.os.urandom = drbg.urandom
    try:
        return mod.encrypt(K, msg, WORKLOAD, shift_mode='dynamic')
    finally:
        mod.os.urandom = orig

def get_bit(buf: bytes, pos: int) -> int:
    b = buf[pos // 8]
    return (b >> (pos % 8)) & 1

def avg_abs_corr(Y):
    means = [stats.mean(col) for col in Y]
    vars_ = [max(1e-9, stats.pvariance(col)) for col in Y]
    acc, cnt = 0.0, 0
    k = len(Y)
    for i in range(k):
        for j in range(i + 1, k):
            cov = stats.mean((a - means[i]) * (b - means[j]) for a, b in zip(Y[i], Y[j]))
            corr = cov / math.sqrt(vars_[i] * vars_[j])
            acc += abs(corr)
            cnt += 1
    return acc / cnt

def main():
    # Build bit-position sample set using the first ciphertext length
    K0 = os.urandom(16)
    msg0 = os.urandom(MSG_SIZE)
    seed0 = 4242
    C0 = enc_std_with_seed(K0, msg0, seed0)
    Lbits = len(C0) * 8
    if SAMPLE_BITS >= Lbits:
        idxs = list(range(Lbits))
    else:
        # evenly spaced positions across the ciphertext
        step = Lbits // SAMPLE_BITS
        idxs = [i * step for i in range(SAMPLE_BITS)]
    Y_std = [[] for _ in idxs]
    Y_mod = [[] for _ in idxs]

    for t in range(TRIALS):
        seed = 4242 + t
        K = os.urandom(16)
        msg = bytearray(os.urandom(MSG_SIZE))
        bit = random.randrange(MSG_SIZE * 8)
        msg2 = bytes(flip_bit(msg, bit))

        C1 = enc_std_with_seed(K, msg, seed)
        C2 = enc_std_with_seed(K, msg2, seed)
        assert len(C1) == len(C2)
        Y = bytes(x ^ y for x, y in zip(C1, C2))
        for i, pos in enumerate(idxs):
            Y_std[i].append(get_bit(Y, pos))

        MC1 = enc_mod_with_seed(K, msg, seed)
        MC2 = enc_mod_with_seed(K, msg2, seed)
        assert len(MC1) == len(MC2)
        YM = bytes(x ^ y for x, y in zip(MC1, MC2))
        for i, pos in enumerate(idxs):
            Y_mod[i].append(get_bit(YM, pos))

    s_bic = avg_abs_corr(Y_std)
    m_bic = avg_abs_corr(Y_mod)

    print("Full-pipeline BIC: average |correlation| of ciphertext-bit flips (lower is better):")
    print(f"- Standard AES:  {s_bic:.3f}")
    print(f"- Modified AES:  {m_bic:.3f}")
    print(f"Winner: {'Modified' if m_bic < s_bic else 'Standard'}")

if __name__ == "__main__":
    main()