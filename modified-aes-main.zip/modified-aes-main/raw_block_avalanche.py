import os
import random
import statistics as stats
import standard_aes as std
import modified_aes as mod

TRIALS = 100

def hb(a: bytes, b: bytes) -> int:
    return sum((x ^ y).bit_count() for x, y in zip(a, b))

def flip_bit(data: bytes, bit_index: int) -> bytes:
    ba = bytearray(data)
    i = bit_index // 8
    m = 1 << (bit_index % 8)
    ba[i] ^= m
    return bytes(ba)

def main():
    std_scores, mod_scores = [], []

    for _ in range(TRIALS):
        K = os.urandom(16)
        P = os.urandom(16)
        bit = random.randrange(128)
        P2 = flip_bit(P, bit)

        C1 = std.AES(K).encrypt_block(P)
        C2 = std.AES(K).encrypt_block(P2)
        std_scores.append(hb(C1, C2))

        MC1 = mod.AES(K, shift_mode='dynamic').encrypt_block(P)
        MC2 = mod.AES(K, shift_mode='dynamic').encrypt_block(P2)
        mod_scores.append(hb(MC1, MC2))

    ms = lambda xs: float(stats.mean(xs)) if xs else 0.0
    s_avg, m_avg = ms(std_scores), ms(mod_scores)

    print("Block avalanche (bits changed; higher is better) over 100 trials:")
    print(f"- Standard AES:  {s_avg:.3f}")
    print(f"- Modified AES:  {m_avg:.3f}")
    print(f"Winner: {'Modified' if m_avg > s_avg else 'Standard'}")

if __name__ == "__main__":
    main()