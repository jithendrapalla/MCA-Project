import os
import random
import statistics as stats
import math
import standard_aes as std
import modified_aes as mod

TRIALS = 100  # more trials => more stable

def flip_bit(data: bytes, bit_index: int) -> bytes:
    ba = bytearray(data)
    i = bit_index // 8
    m = 1 << (bit_index % 8)
    ba[i] ^= m
    return bytes(ba)

def collect_ybits_std_mod(trials):
    Y_std = [[] for _ in range(128)]
    Y_mod = [[] for _ in range(128)]
    for _ in range(trials):
        K = os.urandom(16)
        P = os.urandom(16)
        bit = random.randrange(128)
        P2 = flip_bit(P, bit)

        C1 = std.AES(K).encrypt_block(P)
        C2 = std.AES(K).encrypt_block(P2)
        y = int.from_bytes(bytes(x ^ y for x, y in zip(C1, C2)), 'little')
        for j in range(128):
            Y_std[j].append((y >> j) & 1)

        MC1 = mod.AES(K, shift_mode='dynamic').encrypt_block(P)
        MC2 = mod.AES(K, shift_mode='dynamic').encrypt_block(P2)
        ym = int.from_bytes(bytes(x ^ y for x, y in zip(MC1, MC2)), 'little')
        for j in range(128):
            Y_mod[j].append((ym >> j) & 1)
    return Y_std, Y_mod

def avg_abs_corr(Y):
    means = [stats.mean(col) for col in Y]
    vars_ = [max(1e-9, stats.pvariance(col)) for col in Y]
    acc, cnt = 0.0, 0
    for i in range(128):
        for j in range(i + 1, 128):
            cov = stats.mean((a - means[i]) * (b - means[j]) for a, b in zip(Y[i], Y[j]))
            corr = cov / math.sqrt(vars_[i] * vars_[j])
            acc += abs(corr)
            cnt += 1
    return acc / cnt

def main():
    Y_std, Y_mod = collect_ybits_std_mod(TRIALS)
    s_bic = avg_abs_corr(Y_std)
    m_bic = avg_abs_corr(Y_mod)

    print("BIC: average |correlation| between output-bit flips (lower is better):")
    print(f"- Standard AES:  {s_bic:.3f}")
    print(f"- Modified AES:  {m_bic:.3f}")
    print(f"Winner: {'Modified' if m_bic < s_bic else 'Standard'}")

if __name__ == "__main__":
    main()