import os
import random
import statistics as stats
import standard_aes as std
import modified_aes as mod

TRIALS = 100
THRESHOLD_BITS = 64  # reach ~50% bit differences

def hb(a: bytes, b: bytes) -> int:
    return sum((x ^ y).bit_count() for x, y in zip(a, b))

def flip_bit(data: bytes, bit_index: int) -> bytes:
    ba = bytearray(data)
    i = bit_index // 8
    m = 1 << (bit_index % 8)
    ba[i] ^= m
    return bytes(ba)

def first_onset_round(tr1, tr2, threshold_bits):
    # tr1/tr2 are lists of per-round state bytes (round 1..Nr)
    Nr = min(len(tr1), len(tr2))
    for i in range(Nr):
        if hb(tr1[i], tr2[i]) >= threshold_bits:
            return i + 1  # rounds are 1-based
    return Nr + 1  # not reached

def main():
    std_rounds, mod_rounds = [], []

    for _ in range(TRIALS):
        K = os.urandom(16)
        P = os.urandom(16)
        bit = random.randrange(128)
        P2 = flip_bit(P, bit)

        sA = std.AES(K)
        mA = mod.AES(K, shift_mode='dynamic')

        assert hasattr(sA, "trace_encrypt_rounds"), "standard AES missing trace_encrypt_rounds()"
        assert hasattr(mA, "trace_encrypt_rounds"), "modified AES missing trace_encrypt_rounds()"

        s_tr1 = sA.trace_encrypt_rounds(P)
        s_tr2 = sA.trace_encrypt_rounds(P2)
        m_tr1 = mA.trace_encrypt_rounds(P)
        m_tr2 = mA.trace_encrypt_rounds(P2)

        std_rounds.append(first_onset_round(s_tr1, s_tr2, THRESHOLD_BITS))
        mod_rounds.append(first_onset_round(m_tr1, m_tr2, THRESHOLD_BITS))

    ms = lambda xs: float(stats.mean(xs)) if xs else 0.0
    s_avg, m_avg = ms(std_rounds), ms(mod_rounds)

    print(f"Avalanche onset round to reach {THRESHOLD_BITS} bits (lower is better) over 100 trials:")
    print(f"- Standard AES:  {s_avg:.3f}")
    print(f"- Modified AES:  {m_avg:.3f}")
    print(f"Winner: {'Modified' if m_avg < s_avg else 'Standard'}")

if __name__ == "__main__":
    main()