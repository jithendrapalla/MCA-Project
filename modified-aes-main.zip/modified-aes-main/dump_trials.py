import random

def set_deterministic(seed: int):
    random.seed(seed)
    r = random.Random(seed)
    def rb(n=16):
        return bytes(r.getrandbits(8) for _ in range(n))
    return rb  # deterministic rnd_bytes

def flip_bit(b: bytes, bit: int) -> bytes:
    i = bit // 8
    m = 1 << (bit % 8)
    ba = bytearray(b)
    ba[i] ^= m
    return bytes(ba)

def hex16(b: bytes) -> str:
    return b.hex()

def main(seed=1337, n=10):
    rnd_bytes = set_deterministic(seed)

    print("Avalanche trials (key, P, bit, P'):")
    for t in range(n):
        K = rnd_bytes(16)
        P = rnd_bytes(16)
        bit = random.randrange(128)
        P2 = flip_bit(P, bit)
        print(f"{t+1:02d}: K={hex16(K)}  P={hex16(P)}  bit={bit}  P'={hex16(P2)}")

    print("\nKey-sensitivity trials (key, bit, key', P):")
    for t in range(n):
        K = rnd_bytes(16)
        P = rnd_bytes(16)
        bit = random.randrange(128)
        K2 = flip_bit(K, bit)
        print(f"{t+1:02d}: K={hex16(K)}  bit={bit}  K'={hex16(K2)}  P={hex16(P)}")

if __name__ == "__main__":
    # Usage: python dump_trials.py
    main(seed=1337, n=10)