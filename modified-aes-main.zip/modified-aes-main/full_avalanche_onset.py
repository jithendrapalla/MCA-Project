import os, random, statistics as stats, math
import standard_aes as std
import modified_aes as mod

TRIALS = 100
MSG_SIZE = 1024
WORKLOAD = 10000  # PBKDF2 iterations

def hb(a: bytes, b: bytes) -> int:
    assert len(a) == len(b)
    return sum((x ^ y).bit_count() for x, y in zip(a, b))

class DRBG:
    def __init__(self, seed: int):
        self.r = random.Random(seed)
    def urandom(self, n: int) -> bytes:
        return bytes(self.r.getrandbits(8) for _ in range(n))

def flip_bit(data: bytes, bit_index: int) -> bytes:
    ba = bytearray(data)
    i = bit_index // 8
    ba[i] ^= 1 << (bit_index % 8)
    return bytes(ba)

def enc_std_with_seed(K: bytes, msg: bytes, seed: int) -> bytes:
    drbg = DRBG(seed)
    orig = std.os.urandom
    std.os.urandom = drbg.urandom
    try:
        return std.encrypt(K, msg, WORKLOAD)
    finally:
        std.os.urandom = orig

def enc_mod_with_seed(K: bytes, msg: bytes, seed: int) -> bytes:
    drbg = DRBG(seed)
    orig = mod.os.urandom
    mod.os.urandom = drbg.urandom
    try:
        return mod.encrypt(K, msg, WORKLOAD, shift_mode='dynamic')
    finally:
        mod.os.urandom = orig

def onset_blocks(C1: bytes, C2: bytes) -> int:
    # Full pipeline has no round trace; measure onset across ciphertext growth by 16-byte blocks.
    n_blocks = (len(C1) + 15) // 16
    for i in range(1, n_blocks + 1):
        pref = min(i * 16, len(C1))
        hd = hb(C1[:pref], C2[:pref])
        if hd >= 0.5 * pref * 8:
            return i
    return n_blocks + 1

def main():
    std_rounds, mod_rounds = [], []

    for t in range(TRIALS):
        seed = 987654 + t
        K = os.urandom(16)
        msg = bytearray(os.urandom(MSG_SIZE))
        bit = random.randrange(MSG_SIZE * 8)
        msg2 = bytes(flip_bit(msg, bit))

        C1 = enc_std_with_seed(K, msg, seed)
        C2 = enc_std_with_seed(K, msg2, seed)
        assert len(C1) == len(C2)
        std_rounds.append(onset_blocks(C1, C2))

        MC1 = enc_mod_with_seed(K, msg, seed)
        MC2 = enc_mod_with_seed(K, msg2, seed)
        assert len(MC1) == len(MC2)
        mod_rounds.append(onset_blocks(MC1, MC2))

    m = lambda xs: float(stats.mean(xs)) if xs else 0.0
    s_avg, m_avg = m(std_rounds), m(mod_rounds)
    print("Full-pipeline avalanche onset by ciphertext blocks to reach 50% bits (lower is better):")
    print(f"- Standard AES:  {s_avg:.3f} blocks")
    print(f"- Modified AES:  {m_avg:.3f} blocks")
    print(f"Winner: {'Modified' if m_avg < s_avg else 'Standard'}")

if __name__ == "__main__":
    main()