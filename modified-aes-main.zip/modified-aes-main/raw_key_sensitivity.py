import os
import random
import statistics as stats
import standard_aes as std
import modified_aes as mod

TRIALS = 100

def hb(a: bytes, b: bytes) -> int:
    return sum((x ^ y).bit_count() for x, y in zip(a, b))

def flip_bit(data: bytes, bit_index: int) -> bytes:
    ba = bytearray(data)
    i = bit_index // 8
    m = 1 << (bit_index % 8)
    ba[i] ^= m
    return bytes(ba)

def main():
    enc_std, enc_mod = [], []
    dec_std, dec_mod = [], []

    for _ in range(TRIALS):
        K = os.urandom(16)
        bit = random.randrange(128)
        K2 = flip_bit(K, bit)
        P = os.urandom(16)

        # Standard AES
        sK = std.AES(K)
        sK2 = std.AES(K2)
        C1 = sK.encrypt_block(P)
        C2 = sK2.encrypt_block(P)
        enc_std.append(hb(C1, C2))

        # Decrypt same ciphertext with correct and flipped key
        C = C1  # ciphertext under K
        P1 = sK.decrypt_block(C)
        P2 = sK2.decrypt_block(C)
        dec_std.append(hb(P1, P2))

        # Modified AES (dynamic ShiftRows)
        mK = mod.AES(K, shift_mode='dynamic')
        mK2 = mod.AES(K2, shift_mode='dynamic')
        MC1 = mK.encrypt_block(P)
        MC2 = mK2.encrypt_block(P)
        enc_mod.append(hb(MC1, MC2))

        MC = MC1
        MP1 = mK.decrypt_block(MC)
        MP2 = mK2.decrypt_block(MC)
        dec_mod.append(hb(MP1, MP2))

    def mean(xs): return float(stats.mean(xs)) if xs else 0.0

    print("Key sensitivity over 100 trials (bits changed; higher is better):")
    print(f"- Standard AES:  encrypt={mean(enc_std):.3f}  decrypt={mean(dec_std):.3f}")
    print(f"- Modified AES:  encrypt={mean(enc_mod):.3f}  decrypt={mean(dec_mod):.3f}")

    enc_win = "Modified" if mean(enc_mod) > mean(enc_std) else "Standard"
    dec_win = "Modified" if mean(dec_mod) > mean(dec_std) else "Standard"
    print(f"Winner (encryption): {enc_win}")
    print(f"Winner (decryption): {dec_win}")

if __name__ == "__main__":
    main()