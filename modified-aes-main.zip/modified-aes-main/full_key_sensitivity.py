import os, random, statistics as stats
import standard_aes as std
import modified_aes as mod

TRIALS = 100
MSG_SIZE = 1024
WORKLOAD = 10000  # PBKDF2 iterations

def hb(a: bytes, b: bytes) -> int:
    assert len(a) == len(b)
    return sum((x ^ y).bit_count() for x, y in zip(a, b))

class DRBG:
    def __init__(self, seed: int):
        self.r = random.Random(seed)
    def urandom(self, n: int) -> bytes:
        return bytes(self.r.getrandbits(8) for _ in range(n))

def flip_bit(data: bytes, bit_index: int) -> bytes:
    ba = bytearray(data)
    i = bit_index // 8
    ba[i] ^= 1 << (bit_index % 8)
    return bytes(ba)

def enc_std_with_seed(K: bytes, msg: bytes, seed: int) -> bytes:
    drbg = DRBG(seed)
    orig = std.os.urandom
    std.os.urandom = drbg.urandom
    try:
        return std.encrypt(K, msg, WORKLOAD)
    finally:
        std.os.urandom = orig

def enc_mod_with_seed(K: bytes, msg: bytes, seed: int) -> bytes:
    drbg = DRBG(seed)
    orig = mod.os.urandom
    mod.os.urandom = drbg.urandom
    try:
        return mod.encrypt(K, msg, WORKLOAD, shift_mode='dynamic')
    finally:
        mod.os.urandom = orig

def main():
    enc_std, enc_mod = [], []

    for t in range(TRIALS):
        seed = 123456 + t  # per-trial deterministic IV/salt
        K = os.urandom(16)
        bit = random.randrange(128)
        K2 = flip_bit(K, bit)
        msg = os.urandom(MSG_SIZE)

        C1 = enc_std_with_seed(K,  msg, seed)
        C2 = enc_std_with_seed(K2, msg, seed)
        assert len(C1) == len(C2)
        enc_std.append(hb(C1, C2))

        MC1 = enc_mod_with_seed(K,  msg, seed)
        MC2 = enc_mod_with_seed(K2, msg, seed)
        assert len(MC1) == len(MC2)
        enc_mod.append(hb(MC1, MC2))

    m = lambda xs: float(stats.mean(xs)) if xs else 0.0
    print("Full-pipeline key sensitivity (ciphertext bits changed; higher is better):")
    print(f"- Standard AES:  encrypt={m(enc_std):.3f}")
    print(f"- Modified AES:  encrypt={m(enc_mod):.3f}")
    print(f"Winner (encryption): {'Modified' if m(enc_mod) > m(enc_std) else 'Standard'}")

if __name__ == "__main__":
    main()