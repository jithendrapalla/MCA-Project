import os
import math
import statistics as stats
import modified_aes as mod
import standard_aes as std  # only to report standard baseline (=0)

KEYS = 100
ROUNDS = 10  # AES-128

def entropy(counts):
    total = sum(counts)
    if total == 0:
        return 0.0
    H = 0.0
    for c in counts:
        if c:
            p = c / total
            H -= p * math.log2(p)
    return H  # max is log2(4)=2

def get_base_shifts(A, rounds=ROUNDS):
    # Prefer a dedicated method if available
    if hasattr(A, "_base_shift_for_round"):
        return [A._base_shift_for_round(r) for r in range(1, rounds + 1)]
    # Fallback: use module-level default_base_shift with round key matrices
    if hasattr(A, "_key_matrices") and hasattr(mod, "default_base_shift"):
        return [mod.default_base_shift(A._key_matrices[r], r) for r in range(1, rounds + 1)]
    # If no API, return zeros (no key-dependent diversity detectable)
    return [0] * rounds

def main():
    std_ent = 0.0  # fixed ShiftRows -> 0 per key
    ents = []
    for _ in range(KEYS):
        K = os.urandom(16)
        A = mod.AES(K, shift_mode='dynamic')
        vals = get_base_shifts(A, ROUNDS)
        counts = [sum(1 for v in vals if v == t) for t in range(4)]
        ents.append(entropy(counts))

    m_ent_avg = float(stats.mean(ents)) if ents else 0.0

    print("Key-dependent shift-schedule entropy over keys (higher is better):")
    print(f"- Standard AES:  {std_ent:.3f}")
    print(f"- Modified AES:  {m_ent_avg:.3f}")
    print(f"Winner: {'Modified' if m_ent_avg > std_ent else 'Standard'}")

if __name__ == "__main__":
    main()