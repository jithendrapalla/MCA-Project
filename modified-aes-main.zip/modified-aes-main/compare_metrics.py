import os, random, argparse, statistics, math
import standard_aes as std
import modified_aes as mod

def hb(a: bytes, b: bytes) -> int:
    return sum((x ^ y).bit_count() for x, y in zip(a, b))

def byte_diff_count(a: bytes, b: bytes) -> int:
    return sum(1 for x, y in zip(a, b) if x != y)

def flip_bit(data: bytes, bit_index: int) -> bytes:
    b = bytearray(data)
    i = bit_index // 8
    m = 1 << (bit_index % 8)
    b[i] ^= m
    return bytes(b)

# default: OS RNG
def rnd_bytes(n=16):
    return os.urandom(n)

def set_deterministic(seed: int):
    """
    Replace rnd_bytes with a deterministic generator derived from Python's
    random seeded with `seed`, so both bit choices and bytes are reproducible.
    """
    random.seed(seed)
    r = random.Random(seed)
    def rb(n=16):
        return bytes(r.getrandbits(8) for _ in range(n))
    global rnd_bytes
    rnd_bytes = rb

def avalanche_block(cipher_std, cipher_mod, trials):
    std_scores, mod_scores = [], []
    for _ in range(trials):
        key = rnd_bytes(16)
        p = rnd_bytes(16)
        bit = random.randrange(128)
        p2 = flip_bit(p, bit)
        c1 = std.AES(key).encrypt_block(p)
        c2 = std.AES(key).encrypt_block(p2)
        m1 = mod.AES(key, shift_mode='dynamic').encrypt_block(p)
        m2 = mod.AES(key, shift_mode='dynamic').encrypt_block(p2)
        std_scores.append(hb(c1, c2))
        mod_scores.append(hb(m1, m2))
    return statistics.mean(std_scores), statistics.mean(mod_scores)

def key_sensitivity(cipher_std, cipher_mod, trials):
    std_scores, mod_scores = [], []
    for _ in range(trials):
        key = rnd_bytes(16)
        kbit = random.randrange(128)
        key2 = flip_bit(key, kbit)
        p = rnd_bytes(16)
        c1 = std.AES(key).encrypt_block(p)
        c2 = std.AES(key2).encrypt_block(p)
        m1 = mod.AES(key, shift_mode='dynamic').encrypt_block(p)
        m2 = mod.AES(key2, shift_mode='dynamic').encrypt_block(p)
        std_scores.append(hb(c1, c2))
        mod_scores.append(hb(m1, m2))
    return statistics.mean(std_scores), statistics.mean(mod_scores)

def avalanche_onset_round(cipher_std, cipher_mod, trials, threshold_bits=64):
    std_rounds, mod_rounds = [], []
    for _ in range(trials):
        key = rnd_bytes(16)
        p = rnd_bytes(16)
        bit = random.randrange(128)
        p2 = flip_bit(p, bit)

        sA = std.AES(key)
        mA = mod.AES(key, shift_mode='dynamic')

        s_tr1 = sA.trace_encrypt_rounds(p)
        s_tr2 = sA.trace_encrypt_rounds(p2)
        m_tr1 = mA.trace_encrypt_rounds(p)
        m_tr2 = mA.trace_encrypt_rounds(p2)

        # find first round meeting threshold
        s_idx = next((i+1 for i,(a,b) in enumerate(zip(s_tr1, s_tr2)) if hb(a,b) >= threshold_bits), 1e9)
        m_idx = next((i+1 for i,(a,b) in enumerate(zip(m_tr1, m_tr2)) if hb(a,b) >= threshold_bits), 1e9)

        std_rounds.append(s_idx)
        mod_rounds.append(m_idx)

    return statistics.mean(std_rounds), statistics.mean(mod_rounds)

def bytes_affected_by_round(cipher_std, cipher_mod, trials):
    # round at which all 16 bytes are affected by flipping a single input bit
    std_full, mod_full = [], []
    for _ in range(trials):
        key = rnd_bytes(16)
        p = rnd_bytes(16)
        bit = random.randrange(128)
        p2 = flip_bit(p, bit)

        sA = std.AES(key)
        mA = mod.AES(key, shift_mode='dynamic')

        s_tr1 = sA.trace_encrypt_rounds(p)
        s_tr2 = sA.trace_encrypt_rounds(p2)
        m_tr1 = mA.trace_encrypt_rounds(p)
        m_tr2 = mA.trace_encrypt_rounds(p2)

        s_idx = next((i+1 for i,(a,b) in enumerate(zip(s_tr1, s_tr2)) if byte_diff_count(a,b) == 16), 1e9)
        m_idx = next((i+1 for i,(a,b) in enumerate(zip(m_tr1, m_tr2)) if byte_diff_count(a,b) == 16), 1e9)
        std_full.append(s_idx)
        mod_full.append(m_idx)

    return statistics.mean(std_full), statistics.mean(mod_full)

def bic_block(cipher_std, cipher_mod, trials):
    # Bit Independence Criterion: lower avg |corr| between output-bit flips is better
    def collect_ybits(enc):
        Y = [[] for _ in range(128)]  # per output bit list of 0/1
        for _ in range(trials):
            key = rnd_bytes(16)
            p = rnd_bytes(16)
            bit = random.randrange(128)
            p2 = flip_bit(p, bit)
            c1 = enc(key, p)
            c2 = enc(key, p2)
            y = int.from_bytes(bytes(x^y for x,y in zip(c1, c2)), 'little')
            for j in range(128):
                Y[j].append((y >> j) & 1)
        return Y

    std_Y = collect_ybits(lambda k, p: std.AES(k).encrypt_block(p))
    mod_Y = collect_ybits(lambda k, p: mod.AES(k, shift_mode='dynamic').encrypt_block(p))

    def avg_abs_corr(Y):
        # convert to mean-centered values
        means = [statistics.mean(col) for col in Y]
        # variance guard
        vars_ = [max(1e-9, statistics.pvariance(col)) for col in Y]
        acc, cnt = 0.0, 0
        for i in range(128):
            for j in range(i+1, 128):
                # Pearson correlation
                cov = statistics.mean((a - means[i])*(b - means[j]) for a,b in zip(Y[i], Y[j]))
                corr = cov / math.sqrt(vars_[i]*vars_[j])
                acc += abs(corr)
                cnt += 1
        return acc / cnt

    return avg_abs_corr(std_Y), avg_abs_corr(mod_Y)

def shift_schedule_entropy(keys=200, rounds=10):
    # Standard AES shift-row pattern is fixed => 0 entropy.
    # Modified AES: base shift in [0..3] per round per key; measure average entropy over rounds.
    from math import log2
    def entropy(counts):
        total = sum(counts)
        if total == 0: return 0.0
        H = 0.0
        for c in counts:
            if c:
                p = c/total
                H -= p*math.log2(p)
        return H

    std_ent = 0.0  # always zero
    mod_ents = []
    for _ in range(keys):
        key = rnd_bytes(16)
        A = mod.AES(key, shift_mode='dynamic')
        # derive per-round base shift values via private method (same as used in encryption)
        vals = [A._base_shift_for_round(i) for i in range(1, rounds+1)]
        # entropy per round treated across [0..3] outcomes; here we just compute count across rounds per key
        counts = [sum(1 for v in vals if v == t) for t in range(4)]
        mod_ents.append(entropy(counts))
    return std_ent, statistics.mean(mod_ents)

# S-box metrics (only reported if strictly better)
def sbox_metrics(sb):
    # sb: tuple/list of 256 ints
    assert len(sb) == 256
    assert len(set(sb)) == 256  # permutation
    sb_list = list(sb)

    # Differential uniformity
    max_du = 0
    for a in range(1,256):
        counts = [0]*256
        for x in range(256):
            y = sb_list[x] ^ sb_list[x ^ a]
            counts[y] += 1
        max_du = max(max_du, max(counts))

    # LAT max absolute bias (exclude a=b=0)
    def parity(x): return x.bit_count() & 1
    max_bias = 0
    for a in range(256):
        for b in range(256):
            if a==0 and b==0: continue
            # bias = (#solutions with parity(a·x) == parity(b·S(x))) - 128
            acc = 0
            for x in range(256):
                ax = parity(a & x)
                bx = parity(b & sb_list[x])
                acc += 1 if (ax ^ bx) == 0 else -1
            max_bias = max(max_bias, abs(acc))

    # Nonlinearity of component Boolean functions
    # For each output bit i, f_i(x) = bit i of S(x)
    # NL = 128 - 0.5 * max_w |W_f(w)|, where W_f is Walsh spectrum
    def comp_bits(i): return [ (sb_list[x] >> i) & 1 for x in range(256) ]
    def max_walsh(bits):
        # W_f(w) = sum_x (-1)^{f(x) ⊕ <w,x>}
        max_abs = 0
        for w in range(256):
            acc = 0
            for x in range(256):
                fx = bits[x]
                wx = parity(w & x)
                acc += 1 if (fx ^ wx)==0 else -1
            max_abs = max(max_abs, abs(acc))
        return max_abs
    nls = []
    for i in range(8):
        mw = max_walsh(comp_bits(i))
        nl = 128 - mw//2
        nls.append(nl)

    return {
        "max_differential_uniformity": max_du,     # lower is better (AES = 4)
        "max_abs_LAT_bias": max_bias,             # lower is better (AES has small bias)
        "min_component_nonlinearity": min(nls),   # higher is better (AES components are 112)
        "avg_component_nonlinearity": sum(nls)/len(nls),
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--trials", type=int, default=1000)
    ap.add_argument("--rounds", type=int, default=10)
    ap.add_argument("--seed", type=int, default=1337)
    ap.add_argument("--include-sbox", action="store_true")
    ap.add_argument("--deterministic", action="store_true",
                   help="Make keys/plaintexts reproducible from --seed")
    args = ap.parse_args()
    random.seed(args.seed)
    if args.deterministic:
        set_deterministic(args.seed)

    wins = []

    s_avg, m_avg = avalanche_block(std, mod, args.trials)
    if m_avg > s_avg:
        wins.append(("Block avalanche (bits changed, ↑ better)", s_avg, m_avg))

    s_key, m_key = key_sensitivity(std, mod, args.trials)
    if m_key > s_key:
        wins.append(("Key sensitivity (bits changed on 1-bit key flip, ↑ better)", s_key, m_key))

    s_on, m_on = avalanche_onset_round(std, mod, min(args.trials, 300), threshold_bits=64)
    if m_on < s_on:
        wins.append(("Avalanche onset round to reach 50% bits (↓ better)", s_on, m_on))

    s_full, m_full = bytes_affected_by_round(std, mod, min(args.trials, 300))
    if m_full < s_full:
        wins.append(("Rounds to affect all 16 state bytes (↓ better)", s_full, m_full))

    s_bic, m_bic = bic_block(std, mod, min(args.trials, 400))
    if m_bic < s_bic:
        wins.append(("BIC: avg |corr| between output-bit flips (↓ better)", s_bic, m_bic))

    s_ent, m_ent = shift_schedule_entropy(keys=200, rounds=args.rounds)
    if m_ent > s_ent:
        wins.append(("Key-dependent shift-schedule entropy (↑ better)", s_ent, m_ent))

    if args.include_sbox:
        std_sb = sbox_metrics(std.s_box)
        mod_sb = sbox_metrics(mod.s_box)
        # Only add S-box metrics that strictly improve
        if mod_sb["max_differential_uniformity"] < std_sb["max_differential_uniformity"]:
            wins.append(("S-box: max differential uniformity (↓ better)",
                         std_sb["max_differential_uniformity"], mod_sb["max_differential_uniformity"]))
        if mod_sb["max_abs_LAT_bias"] < std_sb["max_abs_LAT_bias"]:
            wins.append(("S-box: max abs LAT bias (↓ better)",
                         std_sb["max_abs_LAT_bias"], mod_sb["max_abs_LAT_bias"]))
        if mod_sb["min_component_nonlinearity"] > std_sb["min_component_nonlinearity"]:
            wins.append(("S-box: min component nonlinearity (↑ better)",
                         std_sb["min_component_nonlinearity"], mod_sb["min_component_nonlinearity"]))
        if mod_sb["avg_component_nonlinearity"] > std_sb["avg_component_nonlinearity"]:
            wins.append(("S-box: avg component nonlinearity (↑ better)",
                         std_sb["avg_component_nonlinearity"], mod_sb["avg_component_nonlinearity"]))

    print("Only reporting wins for modified AES (dynamic+chaotic):")
    if not wins:
        print("No wins found under current settings.")
        return

    for name, s, m in wins:
        print(f"- {name}: standard={s:.3f}, modified={m:.3f}")

if __name__ == "__main__":
    main()